﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage.Streams;
using Windows.UI;
using Windows.UI.Input.Inking;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace TestApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    
    public partial class settings : Page
    {

        public settings()
        {

            //ToggleSwitch for Black and White Board
            
            this.InitializeComponent();

            

            //Supported inking device type
            myCanvas.InkPresenter.InputDeviceTypes = Windows.UI.Core.CoreInputDeviceTypes.Mouse | 
                Windows.UI.Core.CoreInputDeviceTypes.Pen | Windows.UI.Core.CoreInputDeviceTypes.Touch;

            //Requesting Sticky Notepad
            ApplicationView.PreferredLaunchViewSize = new Size { Height = 400, Width = 600 };
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.GetForCurrentView().SetPreferredMinSize(new Size { Height = 400, Width = 600 });

            //Load Ink
            loadInk();

            //Saving Notes
            Application.Current.Suspending += new SuspendingEventHandler(OnSuspending);
        }

        private async void OnSuspending(object sender, SuspendingEventArgs args)
        {
            SuspendingDeferral deferral = args.SuspendingOperation.GetDeferral();
            await saveInk();
            deferral.Complete();
        }

        
        private async void loadInk()
        {
            Windows.Storage.StorageFolder storageFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
            try
            {
                Windows.Storage.StorageFile file = await storageFolder.GetFileAsync("multicolorboard.gif");
                if (file != null)
                {
                    // Open a file stream for reading.
                    IRandomAccessStream stream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read);

                    // Read from file.
                    using (var inputStream = stream.GetInputStreamAt(0))
                    {
                        await myCanvas.InkPresenter.StrokeContainer.LoadAsync(stream);
                    }
                    stream.Dispose();
                }
            }
            catch (Exception e)
            {
                // Loading failed.
            }
            //throw new NotImplementedException();
        }


        public async Task saveInk()
        {
            // Get all strokes on the InkCanvas.
            System.Collections.Generic.IReadOnlyList<InkStroke> currentStrokes = myCanvas.InkPresenter.StrokeContainer.GetStrokes();
           
            // Strokes present on ink canvas.
            if (currentStrokes.Count > 0) 
            {
                Windows.Storage.StorageFolder storageFolder = Windows.Storage.ApplicationData.Current.LocalFolder;
                Windows.Storage.StorageFile file = await storageFolder.CreateFileAsync("scratchpad.gif", Windows.Storage.CreationCollisionOption.ReplaceExisting);

                if (file != null)
                {
                    // Prevent updates to the file until updates are finalized with call to CompleteUpdatesAsync.
                    Windows.Storage.CachedFileManager.DeferUpdates(file);

                    // Open a file stream for writing.
                    IRandomAccessStream stream = await file.OpenAsync(Windows.Storage.FileAccessMode.ReadWrite);
                    
                    // Write the ink strokes to the output stream.
                    using (IOutputStream outputStream = stream.GetOutputStreamAt(0))
                    {
                        await myCanvas.InkPresenter.StrokeContainer.SaveAsync(outputStream);
                        await outputStream.FlushAsync();
                    }

                    stream.Dispose();
                   
                    // Finalize write so other apps can update file.
                    Windows.Storage.Provider.FileUpdateStatus status =
                    
                    await Windows.Storage.CachedFileManager.CompleteUpdatesAsync(file);

                    if (status == Windows.Storage.Provider.FileUpdateStatus.Complete)
                    {
                        // File saved successfully
                    }
                    else
                    {
                        // Error saving file
                    }
                }
            }
        }


        //ToggleSwitch code for Dashboard color change (Black and White)
        private void toggleSwitch_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = sender as ToggleSwitch;
            if (toggleSwitch != null)
            {
                if (toggleSwitch.IsOn)
                {
                    grid1.Background = new SolidColorBrush(Colors.White);
                }
                else
                {
                    grid1.Background = new SolidColorBrush(Colors.Black);
                }
            }
        }
    }
}
